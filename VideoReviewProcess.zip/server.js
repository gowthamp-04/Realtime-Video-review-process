const express = require('express')
const cors = require('cors')
const bodyParser = require('body-parser')
const fs = require('fs').promises
const path = require('path')
const { v4: uuidv4 } = require('uuid')

const DATA_DIR = path.join(__dirname, 'data')
const USERS_FILE = path.join(DATA_DIR, 'users.json')
const TASKS_FILE = path.join(DATA_DIR, 'tasks.json')
const PORT = process.env.PORT || 3000

const app = express()
app.use(cors())
app.use(bodyParser.json())

// Ensure data folder exists
async function ensureDataDir() {
  try { await fs.mkdir(DATA_DIR, { recursive: true }) } catch(e){ }
}

async function readJson(file, fallback) {
  try {
    const raw = await fs.readFile(file, 'utf8')
    return JSON.parse(raw)
  } catch(err) {
    return fallback
  }
}

async function writeJson(file, data) {
  await fs.writeFile(file, JSON.stringify(data, null, 2), 'utf8')
}

// Initialize users and tasks if missing
async function init() {
  await ensureDataDir()
  const defaultUsers = [
    { username:'muniyapan', password:'1234', role:'teamlead', name:'Muniyapan' },
    { username:'srikanth', password:'1234', role:'creator', name:'Srikanth' },
    { username:'bhagath', password:'1234', role:'creator', name:'Bhagath' },
    { username:'akshay', password:'1234', role:'creator', name:'Akshay' },
    { username:'abhilash', password:'1234', role:'creator', name:'Abhilash' },
    { username:'srimugan', password:'1234', role:'technical', name:'Srimugan' }
  ]
  const users = await readJson(USERS_FILE, null)
  if(!users) await writeJson(USERS_FILE, defaultUsers)
  const tasks = await readJson(TASKS_FILE, null)
  if(!tasks) await writeJson(TASKS_FILE, [])
}

init().then(() => console.log('Server initialized'))

// --- Authentication ---
app.post('/api/login', async (req,res)=>{
  const { username, password } = req.body
  if(!username || !password) return res.status(400).json({ error: 'username & password required' })
  const users = await readJson(USERS_FILE, [])
  const u = users.find(x => x.username === username && x.password === password)
  if(!u) return res.status(401).json({ error: 'invalid credentials' })
  const { password: pw, ...safe } = u
  res.json(safe)
})

// Get all users (without password)
app.get('/api/users', async (req,res)=>{
  const users = await readJson(USERS_FILE, [])
  const safe = users.map(({password,...rest})=>rest)
  res.json(safe)
})

// Get tasks filtered by user
app.get('/api/tasks', async (req,res)=>{
  const allTasks = await readJson(TASKS_FILE, [])
  const user = req.query.user
  if(!user) return res.json(allTasks)
  const users = await readJson(USERS_FILE, [])
  const me = users.find(u=>u.username===user)
  if(!me) return res.status(400).json({ error:'unknown user' })

  if(me.role==='teamlead') return res.json(allTasks)
  if(me.role==='technical') return res.json(allTasks.filter(t=>t.status==='TechnicalReview' || t.assignedTo===user))
  if(me.role==='creator') return res.json(allTasks.filter(t=>t.assignedTo===user || (t.status==='PeerReview' && t.peers.includes(user))))
  res.json([])
})

// Create task (TeamLead only)
app.post('/api/tasks', async (req,res)=>{
  const { title, assignTo, createdBy } = req.body
  if(!title || !assignTo || !createdBy) return res.status(400).json({ error:'missing fields' })
  const tasks = await readJson(TASKS_FILE, [])
  const users = await readJson(USERS_FILE, [])
  const peers = users.filter(u=>u.role==='creator' && u.username!==assignTo).map(u=>u.username)
  const t = {
    id: uuidv4(),
    title,
    assignedTo: assignTo,
    createdBy,
    status: 'Assigned',
    peers,
    peerApprovals: {},
    timeline: [{when:Date.now(), by:createdBy, action:'Assigned'}],
    awaitingCorrectionsFromCreator:false
  }
  tasks.unshift(t)
  await writeJson(TASKS_FILE, tasks)
  res.json(t)
})

// Update task
app.put('/api/tasks/:id', async (req,res)=>{
  const id = req.params.id
  const payload = req.body
  const tasks = await readJson(TASKS_FILE, [])
  const idx = tasks.findIndex(t=>t.id===id)
  if(idx===-1) return res.status(404).json({ error:'task not found' })
  const t = tasks[idx]

  // Peer action
  if(payload.peer && payload.peerAction){
    t.peerApprovals = t.peerApprovals || {}
    t.peerApprovals[payload.peer] = payload.peerAction
    t.timeline.push({when:Date.now(), by: payload.peer, action: payload.peerAction==='approve'?'PeerApproved':'PeerCorrectionRequested'})
    if(payload.peerAction==='correction') { t.status='CorrectionNeeded'; t.awaitingCorrectionsFromCreator=true }
    const allApproved = t.peers.every(p => t.peerApprovals[p]==='approve')
    if(allApproved) t.status='PeerReviewDone'
    await writeJson(TASKS_FILE, tasks)
    return res.json(t)
  }

  // Generic status change
// Generic status change
  if(payload.status){
    t.status = payload.status
    t.timeline.push({when:Date.now(), by: payload.by||'system', action:payload.status, note:payload.note||''})

    // Reset peer approvals if moving to PeerReview
    if(payload.status==='PeerReview') { 
        t.peerApprovals={}; 
        t.awaitingCorrectionsFromCreator=false 
    }

    // Mark awaiting correction if needed
    if(payload.status==='CorrectionNeeded') t.awaitingCorrectionsFromCreator=true

    // Automatically move to Technical Review after Graphical Review
    if(payload.status==='GraphicalReview'){
        t.status = 'TechnicalReview'
        t.timeline.push({when:Date.now(), by: payload.by||'TeamLead', action:'Moved to TechnicalReview'})
    }
}


  if(payload.assignedTo){
    t.assignedTo = payload.assignedTo
    t.timeline.push({when:Date.now(), by:payload.by||'system', action:`Reassigned to ${payload.assignedTo}`})
  }

  await writeJson(TASKS_FILE, tasks)
  res.json(t)
})

app.use('/', express.static(path.join(__dirname,'public')))

app.listen(PORT, ()=>console.log(`Server running on http://localhost:${PORT}`))
